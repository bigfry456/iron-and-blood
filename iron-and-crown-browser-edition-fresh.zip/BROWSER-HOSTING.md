# Iron & Crown — Browser Edition

Players do NOT need Node.js installed.

## Hosting
The server/host runs Node.js on a web host. Players simply visit the site's HTTPS address.

### Render
1. Upload this project to a GitHub repository.
2. Create a new Web Service on Render.
3. Select the repository.
4. Render can use the included `render.yaml`.
5. Build command: `npm install`
6. Start command: `npm start`

## Local testing
A computer running the server needs Node.js:
```bash
npm install
npm start
```
Then open the displayed localhost address.

## Important
The multiplayer server must be hosted somewhere publicly reachable. A static-only website cannot provide the authoritative multiplayer WebSocket server.
