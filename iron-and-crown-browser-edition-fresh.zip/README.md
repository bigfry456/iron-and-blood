# Iron & Crown — Complete Multiplayer Build

Real-time 2–4 player medieval + modern strategy prototype.

## Included systems
- Medieval/modern hybrid army and resource-driven upgrades
- Buildable houses, barracks, forts, castles, bunkers, bases and prisons
- Garrisonable structures
- Field Engineers with sandbags, barricades and field emplacements
- Trenches and water moats
- Day/night expeditions and temporary camps
- Supply routes and scheduled attacks
- Public trust, discipline, oversight and abstract riot/rebellion pressure
- Multiple bases and officer inspections
- Officers and high-ranking officials with rank/armor differences
- Diplomacy/propaganda hooks
- Spies, sleeper agents, civilian-home hideouts and counter-intelligence
- Disguise/infiltration mechanics
- Prisoners, prisons, abstract intelligence, ransom and POW rescue operations
- Secret Service/internal security
- Culture doctrines
- Fictional belief/religion paths
- Fictional warrior sects tied to belief combinations
- Army formations influenced by culture/belief/sect
- Rank/job/culture/sect cosmetic identifiers
- Multiplayer state synchronization through WebSockets

## Run
1. Install Node.js 18+.
2. Run `npm install`.
3. Run `npm start`.
4. Open the shown local address in a browser.
5. For internet multiplayer, deploy the Node/WebSocket server to a host that supports WebSockets and HTTPS.

This is a game prototype: all religion, sect, intelligence, prisoner, rebellion and propaganda systems are fictional strategy mechanics.
