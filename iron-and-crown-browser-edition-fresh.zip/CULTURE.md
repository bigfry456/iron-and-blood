# Culture & Belief system

Each commander can adopt one or more doctrines by spending gold.

- **Honor**: reduces cost of elite knight-style troops and improves their combat strength.
- **Mercy**: a strategic/social doctrine reserved for future diplomacy, surrender and prisoner mechanics.
- **Innovation**: reduces the cost of advanced machines and improves advanced-unit combat.
- **Tradition**: reserved for future medieval economy, fortification and cultural bonuses.
- **Expansion**: increases income and is intended to interact with territory control.

The system is designed to grow into a branching culture tree where choices permanently shape a faction's identity.

## Bases, Officers & Political Operations
- Players have multiple bases that require periodic officer inspections.
- Higher-ranking officials have stronger armor and provide more valuable intelligence when captured.
- Officials can be intercepted by enemy troops, held as strategic prisoners, interrogated for abstract intelligence, or ransomed for resources.
- Officials can run temporary propaganda campaigns against another player, affecting trust and score.
- Additional bases can be constructed and assigned inspection duties.
